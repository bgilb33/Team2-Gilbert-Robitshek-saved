// Required module
var dgram = require('dgram');
const readline = require('readline');


// Port and IP
var PORT = 49152;
var HOST = '192.168.1.7';

// Create socket
var server = dgram.createSocket('udp4');

// Create server that listens on a port
server.on('listening', function () {
    var address = server.address();
    console.log('UDP Server listening on ' + address.address + ":" + address.port);
});

// // Function to get a number from a user
// async function waitForUserResponse(question) {
//   const rl = readline.createInterface({
//     input: process.stdin,
//     output: process.stdout
//   });

//   return new Promise((resolve) => {
//     rl.question(question, (userInput) => {
//       rl.close();
//       resolve(userInput);
//     });
//   });
// }

function waitForUserResponse(question) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  function clearConsole() {
    process.stdout.write('\x1B[2J\x1B[0f');
  }

  const userInputPromise = new Promise((resolve) => {
    rl.question(question, (userInput) => {
      clearConsole();
      rl.close();
      resolve(userInput);
    });
  });

  const timeoutPromise = new Promise((resolve) => {
    setTimeout(() => {
      resolve('all good');
    }, 9000); // 5 seconds
  });

  return Promise.race([userInputPromise, timeoutPromise]);
}


// On connection, print out received message
server.on('message', async function (message, remote) {
    console.log(remote.address + ':' + remote.port +' - ' + message);


    var userInput = await waitForUserResponse('Please enter something: ');
    if(userInput == "all good"){
      var package = "STATUS: good";
    }
    else{
      var package = "INFO: " + userInput;
    }
    console.log('You entered: ' + package);

    server.send(package, remote.port, remote.address, function (error) {
      if (error) {
        console.log('did not return number');
      } else {
        console.log('returned number');
      }
    });

});

// Bind server to port and IP
server.bind(PORT, HOST);

